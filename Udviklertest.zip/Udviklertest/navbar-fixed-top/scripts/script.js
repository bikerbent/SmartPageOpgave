$(document).ready(function() {
    $('#list').click(function(event){event.preventDefault();$('#products .item').addClass('list-group-item');});
    $('#grid').click(function(event){event.preventDefault();$('#products .item').removeClass('list-group-item');$('#products .item').addClass('grid-group-item');});
});

function GetAllProducts(){
    var request = new XMLHttpRequest();
    request.open('GET', 'http://engros.kogs.websrv01.smartpage.dk/services/getallproducts', true);
    request.onload = function () {
    
      var data = JSON.parse(this.response);
      if (request.status >= 200 && request.status < 400) {
        data.forEach(product => {
          const item = document.createElement('div');
          item.setAttribute('class', 'item  col-xs-4 col-lg-4');

          const thumbnail = document.createElement('div');
          thumbnail.setAttribute('class', 'thumbnail');

          const caption = document.createElement('div');
          caption.setAttribute('class', 'caption');
    
          const h4 = document.createElement('h1');
          h4.addClass('group inner list-group-item-heading');
          h4.textContent = product.title;
    
          const p = document.createElement('p');
          p.addClass('group inner list-group-item-text');
          p.textContent = product.description;

          const row = document.createElement('div')
          row.setAttribute('class', 'row');

          const priceDiv = document.createElement('div')
          priceDiv.setAttribute('class', 'col-xs-12 col-md-6');

          const p2 = document.createElement('p')
          p2.addClass('lead')
          p2.textContent = product.price;

          const buttonDiv = document.createElement('div')
          buttonDiv.setAttribute('class', 'col-xs-12 col-md-6')

          const a = document.createElement('a')
          a.addClass('btn btn-success pull-right');
          a.setAttribute('href', '#')
          a.setAttribute('data-product-id', product.id)
          a.href = "#";
          a.text = "Add to cart";
    
          products.appendChild(item);
          item.appendChild(thumbnail);
          thumbnail.appendChild(caption);
          caption.appendChild(h4);
          caption.appendChild(p);
          caption.appendChild(row);
          row.appendChild(priceDiv);
          priceDiv.appendChild(p2);
          row.appendChild(buttonDiv);
          buttonDiv.appendChild(a);
        })}}
        request.send();
}    

